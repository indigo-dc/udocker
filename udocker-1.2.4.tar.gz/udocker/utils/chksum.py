# -*- coding: utf-8 -*-
""""Checksumming for files"""

import hashlib


class ChkSUM(object):
    """Checksumming for files"""

    def sha256(self, filename):
        """sha256 calculation using hashlib"""
        hash_sha256 = hashlib.sha256()
        try:
            with open(filename, "rb") as filep:
                for chunk in iter(lambda: filep.read(4096), b""):
                    hash_sha256.update(chunk)
            return hash_sha256.hexdigest()
        except (IOError, OSError):
            return ""
